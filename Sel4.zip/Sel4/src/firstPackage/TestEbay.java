package firstPackage;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

import com.google.common.base.Function;

public class TestEbay {

	public static WebDriver driver;
	public static String sSiteName="http://www.ebay.com.au";
	public static String sDriverPath = "C:\\chromedriver_win32\\";
	public static String sItemName = "iPad";
	
	
	//xpath for all the elements invoked in customer journey flow.
	private static final String sUserName = "//*[@id=\"userid\"]";
	private static final String sContinueBtn = "//*[@id=\"signin-continue-btn\"]";
	private static final String sSignIn = "/html/body/header/div[1]/ul[1]/li[1]/span/a";
	private static final String sPass = "//*[@id=\"pass\"]";
	private static final String sSelectType = "//*[@id=\"msku-sel-2\"]";
	private static final String sSearchBox = "//*[@id=\"gh-ac\"]";
	private static final String sSearchResult = "//*[@id=\"gh-btn\"]";
	private static final String sItemToSelect = "/html/body/div[4]/div[4]/div[2]/div[1]/div[2]/ul/li[1]/div/div[2]/a/h3";
	private static final String sBuyItNow = "//*[@id=\"binBtn_btn\"]";
	private static final String sCheckoutAsGuest = "//*[@id=\"sbin-gxo-btn\"]";
	private static final String sAddToCart = "//*[@id=\"atcRedesignId_btn\"]";
	private static final String sViewCart = "/html/body/div[6]/div/div[3]/div/div/div/div[1]/div/div[3]/a[1]";

	
	// user address related elements - xpath
	private static final String sCountry = "//*[@id=\"country\"]";
	private static final String sFirstname = "//*[@id=\"firstName\"]";
	private static final String sLastname = "//*[@id=\"lastName\"]";
	private static final String sStreetaddress ="//*[@id=\"addressLine1\"]";
	private static final String sCity="//*[@id=\"city\"]";
	private static final String sState = "//*[@id=\"stateOrProvince\"]";
	private static final String sPostcode = "//*[@id=\"postalCode\"]";
	private static final String sEmail = "//*[@id=\"email\"]";
	private static final String sConfirmEmail ="//*[@id=\"emailConfirm\"]";
	private static final String sPhone ="//*[@id=\"phoneNumber\"]";	
	private static final String sAddressConfirmButton ="/html/body/div[1]/div/div[1]/div[3]/div[1]/div/div[1]/section[2]/div[2]/div/div/div/div[2]/div[1]/form/div/span/div/button";
	
	
	// payment related elements - xpath
	private static final String sOptionCC = "//*[@id=\"srs2\"]";
	private static final String sCardNumBox = "//*[@id=\"cardNumber\"]";
	private static final String sCardNumExpBox = "//*[@id=\"cardExpiryDate\"]";
	private static final String sSecurityCodeBox = "/*[@id=\"securityCode\"]";
	private static final String sCardHolderFnTxt="//*[@id=\"cardHolderFirstName\"]";
	private static final String sCcardHolderLnTxt="//*[@id=\"cardHolderLastName\"]";
	private static final String sPaydoneButton="/html/body/div[1]/div/div[1]/div[3]/div[1]/div/div[1]/section[1]/div/div/div[3]/div/fieldset/div[2]/div[2]/div/form/div/span/div[1]/button";
	private static final String sCnfrmButton="/html/body/div[1]/div/div[1]/div[3]/div[1]/div/div[2]/div[3]/section/div[2]/form/div/button/span";

	public static void initWebDriver(String URL) throws InterruptedException {

		// Setting up Chrome driver path.
		System.setProperty("webdriver.chrome.driver", sDriverPath + "chromedriver.exe");
		// Launching Chrome browser.
		driver = new ChromeDriver();
		driver.get(URL);
		driver.manage().window().maximize();
	}

	public static void main(String[] args) throws InterruptedException {

		initWebDriver(sSiteName);

		//Step 1: login user (This is to test login before purchase  step 3 is to purchase as guest. Either disable step 1 or step 3)
		//eBayLogin();
		
		//Step 2: Search item on eBay
		eBaySearch();
		
		//Step 3: View cart and checkout
		eBayCheckOut();
		
		//Step 4: provide payment details and confirm purchase.
		eBayPaymentDetails();

		// pause for a second and close the browser.
		Thread.sleep(1000);
		
		//close
		endSession();
	}

	public static void eBayLogin() {
		try {
			
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
	        // click first searched item
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sSignIn))).click();
		    //driver.findElement(By.xpath(sSignIn)).click();
		
		getElement(By.xpath(sUserName)).sendKeys("<username here>");
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sContinueBtn))).click();
		//driver.findElement(By.xpath("//*[@id=\"signin-continue-btn\"]")).click();
		
		
		driver.findElement(By.xpath(sPass)).sendKeys("<password here>");
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"sgnBt\"]"))).click();
		driver.findElement(By.xpath("//*[@id=\"sgnBt\"]")).click();
				
		
		Thread.sleep(500);
		
		} catch (InterruptedException e) {
			// TBD: Auto-generated catch block.
			e.printStackTrace();
		}	
		
	}
	
	public static void eBaySearch() {
		
		// input value in search box
		driver.findElement(By.xpath(sSearchBox)).sendKeys(sItemName);

		WebElement searchResult = getElement(By.xpath(sSearchResult));
		
		searchResult.click();

		WebDriverWait wait = new WebDriverWait(driver, 30);
		
        // click first searched item		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sItemToSelect))).click();
		//wait.until(ExpectedConditions.presenceOfElementLocated(By.id("Beer"))).click();

		// select type and click Buy It Now
		Select drpType = new Select(driver.findElement(By.xpath(sSelectType)));
		drpType.selectByVisibleText("Wifi");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sBuyItNow))).click();
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[7]/div/div[5]/div/div/div/div[2]/div/div[4]/div/button[1]"))).click();
		
		// click checkout as guest
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sCheckoutAsGuest))).click();
		
	}
	
	public static void eBayCheckOut(){
		
		try {
						
			Thread.sleep(100);
			
			// provide delivery details
			Select drpCountry = new Select(driver.findElement(By.xpath(sCountry)));
			drpCountry.selectByVisibleText("Australia");
					
			driver.findElement(By.xpath(sFirstname)).sendKeys("Test");
			driver.findElement(By.xpath(sLastname)).sendKeys("User");
			driver.findElement(By.xpath(sStreetaddress)).sendKeys("Barangaroo");
			driver.findElement(By.xpath(sCity)).sendKeys("Sydney");
					
			Select drpState = new Select(driver.findElement(By.xpath(sState)));
			drpState.selectByVisibleText("New South Wales");	
			
			Thread.sleep(100);
			driver.findElement(By.xpath(sPostcode)).sendKeys("2000");
			driver.findElement(By.xpath(sEmail)).sendKeys("testuser@gmail.com");
			driver.findElement(By.xpath(sConfirmEmail)).sendKeys("testuser@gmail.com");
			driver.findElement(By.xpath(sPhone)).sendKeys("022222222");				
					
			
			// click Buy It Now
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sAddressConfirmButton))).click();
			
		}catch (InterruptedException e) {
			// TBD: Auto-generated catch block.
			e.printStackTrace();
		}
		
	}
	
		
	public static void eBayPaymentDetails(){
	
		try {
			
			    WebDriverWait wait = new WebDriverWait(driver, 30);			
		        // click payment by Credit card
			    wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sOptionCC))).click();
				//getElement(By.xpath(sOptionCC)).click();
				
				// provide credit card details
				driver.findElement(By.xpath(sCardNumBox)).sendKeys("55556666777788889999");
				driver.findElement(By.xpath(sCardHolderFnTxt)).sendKeys("Test");
				driver.findElement(By.xpath(sCcardHolderLnTxt)).sendKeys("User");
				driver.findElement(By.xpath(sCardNumExpBox)).sendKeys("1//22");
				driver.findElement(By.xpath(sSecurityCodeBox)).sendKeys("123");
				
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sPaydoneButton))).click();
				//getElement(By.xpath(sPaydoneButton)).click();
				
				
				// confirm payment
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(sCnfrmButton))).click();
				//getElement(By.xpath(sCnfrmButton)).click();
						
				
				Thread.sleep(500);
				
				} catch (InterruptedException e) {
					// TBD: Auto-generated catch block.
					e.printStackTrace();
				}	
				
	}

	public static WebElement getElement(final By locator){
		
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);

		WebElement element = wait.until(new Function<WebDriver, WebElement>() {

			@Override
			public WebElement apply(WebDriver arg0) {
				return arg0.findElement(locator);
			}

		});

		return element;
	}

	public static void endSession()	{
		driver.close();
		driver.quit();
	}
}
